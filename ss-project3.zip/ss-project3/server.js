// Enhanced Express server with Supabase and Authentication
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

// Helper function for ISO timestamp
function nowISO() {
  return new Date().toISOString();
}

const app = express();
const PORT = process.env.PORT || 3000;

// Check if Supabase credentials are available
const hasSupabaseCredentials = process.env.SUPABASE_URL && 
  process.env.SUPABASE_URL !== 'https://your-project-id.supabase.co' &&
  process.env.SUPABASE_SERVICE_ROLE_KEY && 
  process.env.SUPABASE_SERVICE_ROLE_KEY !== 'your_supabase_service_role_key_here';

let supabase = null;
let dataStore = {
  orders: [],
  payments: []
};

const DATA_FILE = path.join(__dirname, 'data.json');

if (hasSupabaseCredentials) {
  const { createClient } = require('@supabase/supabase-js');
  supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_ROLE_KEY
  );
  console.log('Using Supabase database');
} else {
  // Fallback to JSON file storage for development
  console.log('Using JSON file storage (development mode)');
  
  // Load existing data if file exists
  if (fs.existsSync(DATA_FILE)) {
    try {
      const fileData = fs.readFileSync(DATA_FILE, 'utf8');
      dataStore = JSON.parse(fileData);
    } catch (error) {
      console.log('Could not load existing data, starting fresh');
    }
  }
}

// Helper function to save data to JSON file
function saveDataToFile() {
  if (!supabase) {
    try {
      fs.writeFileSync(DATA_FILE, JSON.stringify(dataStore, null, 2));
    } catch (error) {
      console.error('Error saving data to file:', error);
    }
  }
}

// Middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.JWT_SECRET || 'fallback-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// Serve static files
app.use(express.static(path.join(__dirname)));

// Initialize database tables
async function initializeDatabase() {
  try {
    if (supabase) {
      // Supabase initialization - tables should be created manually in Supabase dashboard
      console.log('Using Supabase - ensure tables are created in your dashboard');
    } else {
      // JSON file storage - ensure data structure exists
      if (!dataStore.orders) dataStore.orders = [];
      if (!dataStore.payments) dataStore.payments = [];
      saveDataToFile();
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
  }
}

// Authentication middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.isAdmin) {
    return next();
  }
  return res.status(401).json({ error: 'Authentication required' });
}

// Helper functions
function nowISO() { return new Date().toISOString(); }

// Admin Authentication Routes
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const adminUsername = process.env.ADMIN_USERNAME || 'admin';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

    if (username === adminUsername && password === adminPassword) {
      req.session.isAdmin = true;
      req.session.username = username;
      res.json({ success: true, message: 'Login successful' });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout failed' });
    }
    res.json({ success: true, message: 'Logout successful' });
  });
});

app.get('/api/admin/check', (req, res) => {
  if (req.session && req.session.isAdmin) {
    res.json({ authenticated: true, username: req.session.username });
  } else {
    res.json({ authenticated: false });
  }
});

// API: Create order
app.post('/api/orders', async (req, res) => {
  try {
    const { firstName, lastName, email, phone, totalAmount = 399, currency = 'INR' } = req.body || {};
    
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const id = 'ORD-' + new Date().getFullYear() + '-' + uuidv4().slice(0, 8).toUpperCase();
    const customer_name = [firstName, lastName].filter(Boolean).join(' ').trim() || null;
    const now = nowISO();
    if (supabase) {
      // Supabase implementation
      const { data, error } = await supabase
        .from('orders')
        .insert([{
          id,
          customer_name,
          customer_email: email,
          phone: phone || null,
          total_amount: Number(totalAmount),
          currency,
          status: 'pending',
          created_at: now,
          updated_at: now
        }])
        .select();

      if (error) {
        console.error('Supabase error:', error);
        return res.status(500).json({ error: 'Failed to create order' });
      }
    } else {
      // JSON file storage implementation
      const order = {
        id,
        customer_name,
        customer_email: email,
        customer_phone: phone || null,
        product_name: 'Premium Course Bundle',
        quantity: 1,
        total_amount: Number(totalAmount),
        currency,
        status: 'pending',
        created_at: now,
        updated_at: now
      };
      
      dataStore.orders.push(order);
      saveDataToFile();
    }

    res.json({ id, status: 'pending' });
  } catch (e) {
    console.error('Create order error:', e);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// API: Record payment
app.post('/api/payments', async (req, res) => {
  try {
    const { orderId, amount = 399, currency = 'INR', provider = 'manual', providerPaymentId = null, status = 'succeeded' } = req.body || {};
    
    if (!orderId) {
      return res.status(400).json({ error: 'Order ID is required' });
    }

    let order = null;

    if (supabase) {
      // Check if order exists in Supabase
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();

      if (orderError || !orderData) {
        return res.status(404).json({ error: 'Order not found' });
      }
      order = orderData;
    } else {
       // Check if order exists in JSON storage
       order = dataStore.orders.find(o => o.id === orderId);
       
       if (!order) {
         return res.status(404).json({ error: 'Order not found' });
       }
     }

    const id = 'PAY-' + uuidv4().slice(0, 8).toUpperCase();
    const now = new Date().toISOString();

    if (supabase) {
      // Insert payment record in Supabase
      const { data: payment, error: paymentError } = await supabase
        .from('payments')
        .insert([{
          id,
          order_id: orderId,
          provider,
          provider_payment_id: providerPaymentId,
          amount: Number(amount),
          currency,
          status,
          received_at: now
        }])
        .select();

      if (paymentError) {
        console.error('Payment insert error:', paymentError);
        return res.status(500).json({ error: 'Failed to record payment' });
      }

      // Update order status if payment succeeded
      if (status === 'succeeded') {
        const { error: updateError } = await supabase
          .from('orders')
          .update({ status: 'paid', updated_at: now })
          .eq('id', orderId);

        if (updateError) {
          console.error('Order update error:', updateError);
        }
      }
    } else {
       // Insert payment record in JSON storage
       const payment = {
         id,
         order_id: orderId,
         provider,
         provider_payment_id: providerPaymentId,
         amount: Number(amount),
         currency,
         status,
         received_at: now
       };
       
       dataStore.payments.push(payment);

       // Update order status if payment succeeded
       if (status === 'succeeded') {
         const orderIndex = dataStore.orders.findIndex(o => o.id === orderId);
         if (orderIndex !== -1) {
           dataStore.orders[orderIndex].status = 'paid';
           dataStore.orders[orderIndex].updated_at = now;
         }
       }
       
       saveDataToFile();
     }

    res.json({ id, orderId, status });
  } catch (e) {
    console.error('Record payment error:', e);
    res.status(500).json({ error: 'Failed to record payment' });
  }
});

// API: Admin stats (protected)
app.get('/api/admin/stats', requireAuth, async (req, res) => {
  try {
    let totalOrders = 0;
    let paidOrders = 0;
    let totalRevenue = 0;
    let recentPayments = [];

    if (supabase) {
      // Get total orders from Supabase
      const { count: totalOrdersCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true });

      // Get paid orders from Supabase
      const { count: paidOrdersCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'paid');

      // Get total revenue from Supabase
      const { data: revenueData } = await supabase
        .from('payments')
        .select('amount')
        .eq('status', 'succeeded');

      totalRevenue = revenueData?.reduce((sum, payment) => sum + payment.amount, 0) || 0;

      // Get recent payments from Supabase
      const { data: recentPaymentsData } = await supabase
        .from('payments')
        .select('id, order_id, amount, currency, status, received_at')
        .order('received_at', { ascending: false })
        .limit(10);

      totalOrders = totalOrdersCount || 0;
      paidOrders = paidOrdersCount || 0;
      recentPayments = recentPaymentsData || [];
    } else {
       // Get stats from JSON storage
       totalOrders = dataStore.orders.length;
       paidOrders = dataStore.orders.filter(order => order.status === 'paid').length;
       totalRevenue = dataStore.payments
         .filter(payment => payment.status === 'succeeded')
         .reduce((sum, payment) => sum + payment.amount, 0);
       
       recentPayments = dataStore.payments
         .sort((a, b) => new Date(b.received_at) - new Date(a.received_at))
         .slice(0, 10)
         .map(payment => ({
           id: payment.id,
           order_id: payment.order_id,
           amount: payment.amount,
           currency: payment.currency,
           status: payment.status,
           received_at: payment.received_at
         }));
     }

    res.json({
      totalOrders,
      paidOrders,
      totalRevenue,
      recentPayments
    });
  } catch (e) {
    console.error('Stats error:', e);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

// API: Get all orders (protected)
app.get('/api/admin/orders', requireAuth, async (req, res) => {
  try {
    let orders = [];

    if (supabase) {
      const { data: ordersData, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Orders fetch error:', error);
        return res.status(500).json({ error: 'Failed to fetch orders' });
      }

      orders = ordersData || [];
    } else {
       orders = dataStore.orders
         .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
     }

    res.json({ orders });
  } catch (e) {
    console.error('Get orders error:', e);
    res.status(500).json({ error: 'Failed to get orders' });
  }
});

// Main page endpoints
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/gallery', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/products', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/features', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Payment page endpoints
app.get('/payment', (req, res) => {
  res.sendFile(path.join(__dirname, 'payment.html'));
});

app.get('/checkout', (req, res) => {
  res.sendFile(path.join(__dirname, 'payment.html'));
});

app.get('/buy', (req, res) => {
  res.sendFile(path.join(__dirname, 'payment.html'));
});

// Serve admin login page
app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin-login.html'));
});

// Serve admin dashboard (protected)
app.get('/admin', (req, res) => {
  if (req.session && req.session.isAdmin) {
    res.sendFile(path.join(__dirname, 'admin.html'));
  } else {
    res.redirect('/admin/login');
  }
});

app.get('/admin/dashboard', (req, res) => {
  if (req.session && req.session.isAdmin) {
    res.sendFile(path.join(__dirname, 'admin.html'));
  } else {
    res.redirect('/admin/login');
  }
});

// Health check endpoint for production monitoring
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: nowISO(),
    database: supabase ? 'supabase' : 'json-file',
    uptime: process.uptime()
  });
});

// API status endpoint
app.get('/api/status', (req, res) => {
  res.status(200).json({
    status: 'operational',
    version: '1.0.0',
    database: supabase ? 'connected' : 'file-storage',
    endpoints: [
      '/',
      '/home',
      '/gallery', 
      '/products',
      '/features',
      '/payment',
      '/checkout',
      '/buy',
      '/admin',
      '/admin/login',
      '/admin/dashboard'
    ]
  });
});

// Catch-all route for SPA behavior (must be last)
app.get('*', (req, res) => {
  // If it's an API route that doesn't exist, return 404
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  
  // For all other routes, serve the main page (SPA behavior)
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Initialize database and start server
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Admin panel: http://localhost:${PORT}/admin`);
  });
});